# DMotor
Library for arduino ESP8266 extension.<br> It was made from AFmotor.h. <br>
Use motor shield on Wemos D1 R2 board.
<br> For Adafruit motor shield v1 need to cut off tracks near pins D06 and D11. <br>
For other shield versions - switch PWM pins correspondingly. <br>
http://tracker.digitalmy.ru/view.php?id=211
